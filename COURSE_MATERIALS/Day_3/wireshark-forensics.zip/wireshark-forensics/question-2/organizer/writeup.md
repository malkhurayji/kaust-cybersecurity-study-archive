# Question 2 - Victim IP Address

## Solution

1. Open the PCAP file in Wireshark
2. The victim is the target of the SYN scan - look at the destination IP
3. The web server receiving all the HTTP requests is: `172.28.0.10`

## Answer
`172.28.0.10`
