# Question 6 - 404 Response Count

## Solution

1. Filter for HTTP 404 responses: `http.response.code == 404`
2. Count the number of matching packets
3. In Wireshark: Statistics > HTTP > Packet Counter
4. Total 404 responses: `62`

## Answer
`62`
