# Question 3 - Scanning Technique

## Solution

1. Look at the initial packets from the attacker
2. Filter for TCP packets with only the SYN flag set: `tcp.flags.syn==1 && tcp.flags.ack==0`
3. Notice the pattern of SYN packets to many different ports
4. This is a SYN scan (half-open scan)

## Answer
`SYN scan`
