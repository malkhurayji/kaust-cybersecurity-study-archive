# Question 10 - Failed Login Attempts

## Solution

1. Filter for POST requests to the login page
2. Count requests that resulted in "Invalid credentials" response
3. Total failed attempts before success: `29`

## Answer
`29`
