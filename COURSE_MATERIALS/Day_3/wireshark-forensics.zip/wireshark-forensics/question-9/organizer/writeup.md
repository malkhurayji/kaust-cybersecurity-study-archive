# Question 9 - Target Username

## Solution

1. Filter for HTTP POST requests: `http.request.method == POST`
2. Follow the HTTP stream or examine form data
3. Look at the login attempts to admin.php
4. The targeted username is: `admin`

## Answer
`admin`
