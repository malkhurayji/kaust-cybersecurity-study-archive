# Question 5 - Scanning Tool

## Solution

1. Look at the HTTP requests during the port/service scanning phase
2. Check User-Agent headers or distinctive packet patterns
3. Nmap leaves identifiable fingerprints in its packets
4. The tool used is: `nmap`

## Answer
`nmap`
