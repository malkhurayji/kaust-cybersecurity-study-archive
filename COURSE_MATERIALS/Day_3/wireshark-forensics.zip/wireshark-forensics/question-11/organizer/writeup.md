# Question 11 - Successful Password

## Solution

1. Look for the POST request that resulted in a successful login
2. This will have a different response (redirect or success message)
3. Examine the password field in that request
4. The successful password is: `securep@ss123`

## Answer
`securep@ss123`
