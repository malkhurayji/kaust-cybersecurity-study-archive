# Question 13 - Reverse Shell Port

## Solution

1. From the command injection payload, identify the listening port
2. Or filter for new TCP connections from victim to attacker
3. The reverse shell port is: `4444`

## Answer
`4444`
