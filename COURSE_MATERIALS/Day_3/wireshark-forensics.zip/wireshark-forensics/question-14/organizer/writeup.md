# Question 14 - Victim Source Port

## Solution

1. Filter for TCP connection from victim (172.28.0.10) to attacker port 4444
2. `ip.src == 172.28.0.10 && tcp.dstport == 4444`
3. Look at the source port in the SYN packet
4. The victim's source port is: `54762`

## Answer
`54762`
