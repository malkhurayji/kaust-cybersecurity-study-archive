# Question 4 - Web Server Version

## Solution

1. Filter for HTTP responses: `http.response`
2. Examine the Server header in any HTTP response
3. The server header reveals: `Apache/2.4.65 (Debian)`

## Answer
`Apache/2.4.65 (Debian)`
