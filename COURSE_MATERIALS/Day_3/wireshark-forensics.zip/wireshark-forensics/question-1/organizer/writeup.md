# Question 1 - Attacker IP Address

## Solution

1. Open the PCAP file in Wireshark
2. Look at the initial packets - you'll see a SYN scan pattern
3. The source IP initiating the scan is the attacker: `172.28.0.20`

Alternatively, use Statistics > Endpoints to see the two main IPs communicating.

## Answer
`172.28.0.20`
