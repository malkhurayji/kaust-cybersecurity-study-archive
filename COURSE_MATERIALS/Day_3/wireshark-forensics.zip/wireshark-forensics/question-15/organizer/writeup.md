# Question 15 - Persistence File

## Solution

1. Follow the TCP stream of the reverse shell connection
2. Look at the commands executed by the attacker
3. The attacker creates/modifies SSH authorized_keys for persistence
4. The file is: `authorized_keys`

## Answer
`authorized_keys`
