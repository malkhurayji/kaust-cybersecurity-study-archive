# Question 16 - SSH Key Prefix

## Solution

1. Follow the TCP stream of the reverse shell
2. Look for base64-encoded data or SSH key being written
3. Decode any obfuscated commands
4. The SSH key starts with: `AAAAB3NzaC1yc2EA`

## Answer
`AAAAB3NzaC1yc2EA`
