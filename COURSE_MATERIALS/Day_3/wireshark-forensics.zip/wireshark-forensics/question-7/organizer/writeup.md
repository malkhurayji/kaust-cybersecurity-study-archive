# Question 7 - Hidden Admin Page

## Solution

1. Filter for HTTP 200 responses: `http.response.code == 200`
2. Look at the URIs that returned successful responses
3. Besides index.php, the attacker found: `admin.php`

## Answer
`admin.php`
