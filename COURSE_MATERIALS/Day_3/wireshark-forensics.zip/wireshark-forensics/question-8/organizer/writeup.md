# Question 8 - Directory Bruteforce Tool

## Solution

1. Look at HTTP requests during the directory enumeration phase
2. Check the User-Agent header in these requests
3. The User-Agent reveals: `gobuster`

## Answer
`gobuster`
